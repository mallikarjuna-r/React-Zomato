package com.example.React_Spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReactSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
